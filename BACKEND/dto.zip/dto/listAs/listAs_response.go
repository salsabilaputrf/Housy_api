package listasdto


type ListAsResponse struct {
	ID          int			  		`json:"id"`
	Role 		string				`json:"role"`
}